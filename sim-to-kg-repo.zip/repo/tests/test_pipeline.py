import json, os, subprocess, sys, tempfile
H = os.path.dirname(os.path.abspath(__file__)); R = os.path.dirname(H)
S, E = os.path.join(R, "skills", "sim-to-kg", "scripts"), os.path.join(R, "examples")
def run(*a): return subprocess.run([sys.executable, *a], check=True, capture_output=True, text=True).stdout
def test_end_to_end():
    d = tempfile.mkdtemp()
    run(f"{S}/extract_aspen_plus_inp.py", f"{E}/demo.inp", f"{d}/ap.json")
    run(f"{S}/extract_step.py", f"{E}/demo.step", f"{d}/cad.json")
    run(f"{S}/import_pid_kg.py", f"{E}/demo_pid_graph.json", f"{d}/pid.json")
    out = run(f"{S}/build_kg.py", f"{d}/out", f"{d}/pid.json", f"{d}/ap.json", f"{d}/cad.json")
    qa = open(f"{d}/out/qa_report.md").read()
    ap = json.load(open(f"{d}/ap.json"))
    assert {n["id"] for n in ap["nodes"] if n["kind"] == "equipment"} == {"P-101", "E-101", "V-101"}
    assert "TK-101: in pid; NOT in aspen_plus, cad_step" in qa          # tank missing from sim + CAD
    assert "V-101: in aspen_plus, pid; NOT in cad_step" in qa
    assert "x2" in open(f"{d}/out/summary.md").read()                   # FRAME qty 2
    print(out)
if __name__ == "__main__":
    test_end_to_end(); print("PASS")
