# sim-to-kg

[English](README.en.md)

**تبدیل شبیه‌سازی فرایند و مدل CAD به گراف دانش، و تطبیق آن‌ها با P&ID**

`sim-to-kg` یک [اسکیل Claude](https://code.claude.com/docs/en/skills) و مکمل پروژهٔ [`pid-to-kg`](https://github.com/ScottDuncanAI/PID-to-Knowledge-Graph) است. `pid-to-kg` نقشه‌های P&ID را با بینایی ماشین می‌خواند، ولی این اسکیل **منابع ساختاریافته** (شبیه‌سازی و CAD) را مستقیم از فایل یا API می‌خواند و آن‌ها را با تگ تجهیزات به هم تطبیق می‌دهد.

## مشکلی که حل می‌کند

در پروژه‌های صنعتی، P&ID و مدل شبیه‌سازی و مدل سه‌بعدی را تیم‌های جدا نگه می‌دارند و با گذر زمان از هم فاصله می‌گیرند. این اسکیل هر سه را به یک گراف تبدیل می‌کند و ناسازگاری‌ها را گزارش می‌دهد. نمونه‌ها:

- پمپی که در P&ID هست ولی در شبیه‌سازی نیست.
- مخزنی که در شبیه‌سازی هست ولی در مدل سه‌بعدی نیست.
- تجهیزی که در دو منبع تگ یکسان دارد ولی تجهیز بعدیِ جریان در آن‌ها فرق می‌کند.
- ساخت لایهٔ زمینه برای پرسش و پاسخ با LLM، مثل «خروجی E-101 به کجا می‌رود؟».

## منابع پشتیبانی‌شده

| منبع | اسکریپت | نیازمندی |
|---|---|---|
| Aspen HYSYS | `extract_hysys.py` (از طریق COM) | ویندوز، لایسنس HYSYS، `pywin32` |
| Aspen Plus | `extract_aspen_plus_inp.py` (فایل `.inp` خروجی‌گرفته‌شده) | بدون نیاز به نرم‌افزار |
| SolidWorks | `extract_solidworks.py` (از طریق API/COM) | ویندوز، لایسنس SolidWorks، `pywin32` |
| هر نرم‌افزار CAD | `extract_step.py` (فایل STEP ‏AP203/AP214/AP242) | بدون نیاز به نرم‌افزار |
| گراف P&ID | `import_pid_kg.py` (خروجی `pid-to-kg`) | فایل `graph.json` آن |

## خروجی‌ها

اسکریپت `build_kg.py` همهٔ منابع را ادغام می‌کند و این فایل‌ها را می‌سازد:

| فایل | محتوا |
|---|---|
| `summary.md` | خلاصهٔ خوانا: جریان در سطح تجهیزات، ساختار اسمبلی، پوشش تگ‌ها در منابع |
| `qa_report.md` | تگ‌هایی که فقط در بعضی منابع هستند، اختلاف اتصالات پایین‌دست، تجهیزات بدون تگ |
| `graph.json` | گراف کامل |
| `graph.duckdb` | همان گراف برای پرس‌وجوی SQL (اگر `duckdb` نصب باشد) |

## وضعیت: قبل از استفاده بخوانید

- پارسر `.inp` آسپن پلاس، پارسر STEP، ایمپورتر P&ID، ادغام و QA با یک تست مصنوعی سرتاسری بررسی شده‌اند (`python tests/test_pipeline.py`).
- **اکسترکتورهای COM برای HYSYS و SolidWorks روی نرم‌افزار واقعی اجرا نشده‌اند.** آن‌ها از مدل شیء رسمی نرم‌افزارها پیروی می‌کنند، هر خواندن محافظت‌شده است و خطاها در `props._notes` ثبت می‌شوند. ممکن است برای نسخهٔ شما نام بعضی propertyها نیاز به اصلاح داشته باشد (دستور `extract_hysys.py --discover` کمک می‌کند).
- ایمپورتر P&ID ساختار JSON پروژهٔ `pid-to-kg` را حدس می‌زند. اگر تعداد تجهیزات صفر شد، `KIND_MAP` را با `graph.schema.json` آن پروژه تطبیق دهید.
- خروجی‌ها ماشینی‌اند. قبل از استفاده در طراحی، MOC، HAZOP یا LOPA حتماً باید توسط مهندس صلاحیت‌دار بازبینی شوند.

## نصب

1. پوشهٔ `skills/sim-to-kg` را در پوشهٔ اسکیل‌های Claude کپی کنید:
   - ویندوز: `C:\Users\<نام کاربری>\.claude\skills\`
   - مک/لینوکس: `~/.claude/skills/`
2. پکیج‌ها را نصب کنید: `pip install pywin32 duckdb` (`pywin32` فقط برای اکسترکتورهای COM لازم است).
3. در Claude Code پوشهٔ پروژه‌تان را باز کنید و بنویسید، مثلاً:

> از `plant.inp` و `skid.step` یک گراف دانش بساز و با `pid_graph.json` مقایسه کن.

اسکیل خودکار فعال می‌شود و نیازی به صدا زدن نامش نیست.

## امتحان سریع (بدون شبیه‌ساز و CAD)

```
python tests/test_pipeline.py
python skills/sim-to-kg/scripts/extract_aspen_plus_inp.py examples/demo.inp ap.json
python skills/sim-to-kg/scripts/extract_step.py examples/demo.step cad.json
python skills/sim-to-kg/scripts/import_pid_kg.py examples/demo_pid_graph.json pid.json
python skills/sim-to-kg/scripts/build_kg.py out pid.json ap.json cad.json
```

## نمونهٔ خروجی

خروجی کامل این مثال در `examples/sample-output/` است. سه منبع ورودی یک خط فرایندی ساده را توصیف می‌کنند:

- گراف P&ID شامل P-101، E-101، V-101 و TK-101
- شبیه‌سازی Aspen Plus شامل P-101، E-101 و V-101 (بدون مخزن TK-101)
- اسمبلی STEP شامل P-101، E-101 و یک قاب (FRAME) با تعداد ۲

بخشی از `qa_report.md` تولیدشده:

```
## Tags present in some sources but not others
- SKID-01: in cad_step; NOT in pid, aspen_plus
- TK-101: in pid; NOT in aspen_plus, cad_step
- V-101: in aspen_plus, pid; NOT in cad_step
```

یعنی مخزن TK-101 در P&ID هست ولی نه در شبیه‌سازی و نه در مدل CAD، و V-101 در مدل CAD نیست.

## نمونهٔ دستور برای هر منبع

```
# HYSYS (با کیس باز در نرم‌افزار)
python skills/sim-to-kg/scripts/extract_hysys.py hysys.json --active

# SolidWorks
python skills/sim-to-kg/scripts/extract_solidworks.py sw.json --file C:\cad\skid.sldasm

# تگ‌های توصیفی (مثل "Feed Pump") با فایل aliases.csv
#   source,name,tag
#   aspen_plus,Feed Pump,P-101
python skills/sim-to-kg/scripts/build_kg.py out pid.json hysys.json sw.json --aliases aliases.csv
```

## محدودیت‌ها

- استریم‌های انرژی در HYSYS، منطق Adjust و Recycle و Spreadsheet، و خطوط لولهٔ Routing در SolidWorks هنوز استخراج نمی‌شوند.
- تطبیق تگ بر پایهٔ الگوی `۱ تا ۴ حرف + ۲ تا ۵ رقم + حرف اختیاری` است. نام‌های توصیفی باید در `aliases.csv` معرفی شوند.
- فایل STEP فقط ساختار اسمبلی دارد، نه هندسه و نه propertyهای سفارشی.

جزئیات بیشتر در `skills/sim-to-kg/references/limitations.md` است.

## ساختار پروژه

```
skills/sim-to-kg/
  SKILL.md              جریان کاری که Claude دنبال می‌کند
  references/           ontology و محدودیت‌ها
  scripts/              اکسترکتورها، ادغام، QA
examples/               داده‌های نمونه و sample-output
tests/                  تست سرتاسری
```

## مجوز

MIT. فایل `LICENSE` را ببینید.
