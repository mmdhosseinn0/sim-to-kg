# Engineering-source knowledge graph

| source | tool | file | nodes | edges |
|---|---|---|---|---|
| pid | pid-to-kg | examples/demo_pid_graph.json | 8 | 7 |
| aspen_plus | Aspen Plus (.inp) | examples/demo.inp | 8 | 7 |
| cad_step | STEP assembly | examples/demo.step | 4 | 3 |

## Equipment-level flow: pid

- P-101 -> E-101
- E-101 -> V-101
- V-101 -> TK-101

## Equipment-level flow: aspen_plus

- E-101 -> V-101
- P-101 -> E-101

## Assembly structure

- SKID-01 (cad_step): E-101, FRAME x2, P-101

## Tag coverage across sources

| tag | present in | missing in |
|---|---|---|
| E-101 | aspen_plus, cad_step, pid | - |
| P-101 | aspen_plus, cad_step, pid | - |
| SKID-01 | cad_step | pid, aspen_plus |
| TK-101 | pid | aspen_plus, cad_step |
| V-101 | aspen_plus, pid | cad_step |
