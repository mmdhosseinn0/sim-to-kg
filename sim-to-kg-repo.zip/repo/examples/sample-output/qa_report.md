# QA report

## Errors / warnings
- none

## Tags present in some sources but not others
- SKID-01: in cad_step; NOT in pid, aspen_plus
- TK-101: in pid; NOT in aspen_plus, cad_step
- V-101: in aspen_plus, pid; NOT in cad_step

## Downstream-connectivity disagreements (same tag, different next equipment)
- none

## Untagged equipment/parts (cannot be reconciled; add to aliases.csv if they matter)
- cad_step: FRAME
