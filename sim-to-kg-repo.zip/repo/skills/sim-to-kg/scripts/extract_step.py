#!/usr/bin/env python
"""STEP (.step/.stp, AP203/AP214/AP242) assembly structure -> source JSON.
No SolidWorks needed: export 'STEP AP214' from SolidWorks (or any CAD) and run this.
Captures product names and parent/child occurrences with quantities. Geometry is ignored.

usage: extract_step.py model.step out.json [--source cad_step]
"""
import argparse
import json
import re
from collections import Counter


def split_statements(text):
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    out, buf, q = [], [], False
    for ch in text:
        if ch == "'":
            q = not q
        if ch == ";" and not q:
            out.append("".join(buf).strip())
            buf = []
        else:
            buf.append(ch)
    return out


def split_args(s):
    args, depth, q, cur = [], 0, False, []
    for ch in s:
        if ch == "'":
            q = not q
        if not q:
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
            elif ch == "," and depth == 0:
                args.append("".join(cur).strip())
                cur = []
                continue
        cur.append(ch)
    args.append("".join(cur).strip())
    return args


def unq(s):
    s = s.strip()
    s = s[1:-1].replace("''", "'") if len(s) >= 2 and s[0] == "'" and s[-1] == "'" else s
    return re.sub(r"\\X2\\([0-9A-Fa-f]+)\\X0\\",
                  lambda m: "".join(chr(int(m.group(1)[i:i + 4], 16)) for i in range(0, len(m.group(1)), 4)), s)


def parse(text, source="cad_step", file=None):
    ents = {}
    for st in split_statements(text):
        m = re.match(r"#(\d+)\s*=\s*([A-Z0-9_]+)\s*\((.*)\)\s*$", st, re.S)
        if m:
            ents[m.group(1)] = (m.group(2), split_args(m.group(3)))
    product, formation, pdef, nauo = {}, {}, {}, []
    for i, (t, a) in ents.items():
        if t == "PRODUCT":
            product[i] = unq(a[1]) or unq(a[0])
        elif t.startswith("PRODUCT_DEFINITION_FORMATION"):
            formation[i] = a[2].lstrip("#")
        elif t == "PRODUCT_DEFINITION":
            pdef[i] = a[2].lstrip("#")
        elif t == "NEXT_ASSEMBLY_USAGE_OCCURRENCE":
            nauo.append((a[3].lstrip("#"), a[4].lstrip("#"), unq(a[1]) or unq(a[0])))

    def pname(pd):
        return product.get(formation.get(pdef.get(pd, ""), ""), f"pd{pd}")

    parents, cnt, inst = set(), Counter(), {}
    for par, ch, nm in nauo:
        cnt[(pname(par), pname(ch))] += 1
        inst.setdefault(pname(ch), []).append(nm)
        parents.add(pname(par))
    names = {pname(pd) for pd in pdef}
    children = {c for (_, c) in cnt}
    nodes = [{"id": n, "kind": "assembly" if n in parents else "part", "name": n,
              "props": {"instances": inst.get(n, [])[:20], "root": n not in children}}
             for n in sorted(names)]
    edges = [{"from": p, "to": c, "type": "contains", "props": {"qty": q}} for (p, c), q in sorted(cnt.items())]
    return {"source": source, "tool": "STEP assembly", "file": file, "nodes": nodes, "edges": edges}


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("step")
    ap.add_argument("out")
    ap.add_argument("--source", default="cad_step")
    a = ap.parse_args()
    with open(a.step, encoding="utf-8", errors="replace") as f:
        d = parse(f.read(), a.source, a.step)
    with open(a.out, "w", encoding="utf-8") as f:
        json.dump(d, f, indent=1, ensure_ascii=False)
    print(f"{len(d['nodes'])} nodes, {len(d['edges'])} edges -> {a.out}")
