"""Small helpers for late-bound COM (win32com). Windows only."""


def call(obj, name, *args):
    """Late-bound COM exposes some zero-arg methods as properties; handle both."""
    attr = getattr(obj, name)
    return attr(*args) if callable(attr) else attr


def seq(coll):
    """Iterate a HYSYS-style collection (Count + 0-based Item(i)) or a plain tuple."""
    if coll is None:
        return []
    if isinstance(coll, (tuple, list)):
        return list(coll)
    try:
        return [coll.Item(i) for i in range(int(coll.Count))]
    except Exception:
        return []


def val(obj, unit=None):
    """Read a HYSYS RealVariable in a given unit, falling back to .Value. None if unavailable."""
    try:
        if unit:
            return float(obj.GetValue(unit))
    except Exception:
        pass
    try:
        return float(obj.Value)
    except Exception:
        return None


def discover(obj, limit=200):
    """Public attribute names of a COM object - use when an attribute guess fails."""
    try:
        return sorted(a for a in dir(obj) if not a.startswith("_"))[:limit]
    except Exception:
        return []
