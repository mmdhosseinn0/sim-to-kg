#!/usr/bin/env python
"""Aspen Plus input file (.inp, File > Export > Input File) -> source JSON. Pure text parsing:
no Aspen install, no COM, works on any OS.

usage: extract_aspen_plus_inp.py model.inp out.json [--source aspen_plus]
"""
import argparse
import json
import re


def paragraphs(text):
    lines = []
    for raw in text.splitlines():
        line = raw.split(";")[0].rstrip()          # ';' starts a comment
        if not line.strip():
            continue
        if line.lstrip().startswith("&") and lines:  # '&' continues previous line
            lines[-1] += " " + line.lstrip()[1:].strip()
            continue
        lines.append(line)
    paras, cur = [], None
    for line in lines:
        if not line[0].isspace():                   # unindented line = new paragraph header
            cur = {"head": line.split(), "body": []}
            paras.append(cur)
        elif cur is not None:
            cur["body"].append(line.strip())
    return paras


def kv(line):
    return {m.group(1).upper(): m.group(2) for m in re.finditer(r"([A-Za-z][\w-]*)\s*=\s*([^\s=]+)", line)}


def parse(text, source="aspen_plus", file=None):
    nodes, edges = {}, []
    btype, bprops, sprops = {}, {}, {}
    conns = []
    for p in paragraphs(text):
        h = [t.upper() for t in p["head"]]
        if h[0] == "FLOWSHEET":
            for line in p["body"]:
                m = re.match(r"BLOCK\s+(\S+)\s*(.*)$", line, re.I)
                if not m:
                    continue
                name, rest = m.group(1), m.group(2)
                mi = re.search(r"\bIN\s*=\s*(.*?)(?=\bOUT\s*=|$)", rest, re.I)
                mo = re.search(r"\bOUT\s*=\s*(.*?)(?=\bIN\s*=|$)", rest, re.I)
                conns.append((name, mi.group(1).split() if mi else [], mo.group(1).split() if mo else []))
        elif h[0] == "BLOCK" and len(h) >= 2:
            if len(p["head"]) >= 3:
                btype[p["head"][1]] = p["head"][2]
            props = {}
            for line in p["body"]:
                if line.upper().startswith("PARAM"):
                    props.update({k.lower(): v for k, v in kv(line).items()})
            bprops[p["head"][1]] = props
        elif h[0] == "STREAM" and len(h) >= 2:
            props = {}
            for line in p["body"]:
                props.update({k.lower(): v for k, v in kv(line).items()})
            sprops[p["head"][1]] = props
    used_in, used_out = set(), set()
    for name, ins, outs in conns:
        nodes[name] = {"id": name, "kind": "equipment", "name": name,
                       "type": btype.get(name), "props": bprops.get(name, {})}
        for s in ins:
            used_in.add(s)
            edges.append({"from": s, "to": name, "type": "feeds"})
        for s in outs:
            used_out.add(s)
            edges.append({"from": name, "to": s, "type": "produces"})
    for s in sorted(used_in | used_out | set(sprops)):
        role = "feed" if s in used_in and s not in used_out else "product" if s in used_out and s not in used_in else "internal"
        nodes[s] = {"id": s, "kind": "stream", "name": s, "type": role, "props": sprops.get(s, {})}
    return {"source": source, "tool": "Aspen Plus (.inp)", "file": file,
            "nodes": list(nodes.values()), "edges": edges}


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("inp")
    ap.add_argument("out")
    ap.add_argument("--source", default="aspen_plus")
    a = ap.parse_args()
    with open(a.inp, encoding="utf-8", errors="replace") as f:
        d = parse(f.read(), a.source, a.inp)
    with open(a.out, "w", encoding="utf-8") as f:
        json.dump(d, f, indent=1)
    print(f"{len(d['nodes'])} nodes, {len(d['edges'])} edges -> {a.out}")
