#!/usr/bin/env python
"""Aspen HYSYS flowsheet -> source JSON via COM. Windows + licensed HYSYS + `pip install pywin32`.

usage:
  extract_hysys.py out.json --active                # use the case currently open in HYSYS
  extract_hysys.py out.json --file C:\\cases\\plant.hsc
  extract_hysys.py out.json --active --discover     # dump attribute names of the first op/stream/controller
                                                    # (use if a property name differs in your HYSYS version)

UNTESTED against a live HYSYS in the authoring environment: property names follow the HYSYS automation
object model, and every read is wrapped so a wrong name degrades to a missing value + a note in
`props._notes`, never a crash. Run --discover and fix names in PROPS / CONTROLLER_ATTRS if needed.
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comutil import call, discover, seq, val

PROPS = {  # stream property -> (attribute, unit)
    "T_C": ("Temperature", "C"), "P_kPa": ("Pressure", "kPa"),
    "mass_flow_kg_h": ("MassFlow", "kg/h"), "molar_flow_kmol_h": ("MolarFlow", "kgmole/h"),
    "vapour_fraction": ("VapourFraction", None),
}
CONTROLLER_ATTRS = {"pv": ["PVOwnerObject", "PVObject", "ProcessVariableObject"],
                    "op": ["OPOwnerObject", "OPObject", "OutputObject"]}
CONTROLLER_TYPES = ("controllerop", "pidcontrol", "pidcontroller", "mpc")


def sid(prefix, name):
    return f"{prefix}{name}"


def walk(fs, prefix, nodes, edges, discover_mode, seen_disc):
    mats = {s.Name: s for s in seq(call(fs, "MaterialStreams"))}
    for name, s in mats.items():
        props = {}
        for key, (attr, unit) in PROPS.items():
            try:
                props[key] = val(getattr(s, attr), unit)
            except Exception:
                props[key] = None
        nodes.append({"id": sid(prefix, name), "kind": "stream", "name": name, "type": "material", "props": props})
        if discover_mode and "stream" not in seen_disc:
            seen_disc["stream"] = discover(s)

    connected = 0
    for op in seq(call(fs, "Operations")):
        name = op.Name
        tname = str(getattr(op, "TypeName", "")).lower()
        is_ctl = any(t in tname for t in CONTROLLER_TYPES)
        notes = []
        node = {"id": sid(prefix, name), "kind": "controller" if is_ctl else "equipment",
                "name": name, "type": tname, "props": {}}
        nodes.append(node)
        if discover_mode and ("ctl" if is_ctl else "op") not in seen_disc:
            seen_disc["ctl" if is_ctl else "op"] = discover(op)
        if tname == "subflowsheet" or tname.startswith("sub"):
            try:
                walk(op.Flowsheet, f"{prefix}{name}/", nodes, edges, discover_mode, seen_disc)
            except Exception as e:
                notes.append(f"subflowsheet not entered: {e}")
        if is_ctl:
            for role, cands in CONTROLLER_ATTRS.items():
                for c in cands:
                    try:
                        target = getattr(op, c)
                        node["props"][role + "_object"] = getattr(target, "Name", str(target))
                        break
                    except Exception:
                        continue
                else:
                    notes.append(f"{role} object not found (tried {cands})")
            for role, key in (("pv", "pv_object"), ("op", "op_object")):
                tgt = node["props"].get(key)
                if tgt and sid(prefix, tgt) in {n["id"] for n in nodes}:
                    edges.append({"from": sid(prefix, name) if role == "op" else sid(prefix, tgt),
                                  "to": sid(prefix, tgt) if role == "op" else sid(prefix, name), "type": "signal"})
            node["props"]["_notes"] = notes
            continue
        for attr, direction in (("AttachedFeeds", "in"), ("AttachedProducts", "out")):
            try:
                for st in seq(call(op, attr)):
                    a, b = (sid(prefix, st.Name), sid(prefix, name)) if direction == "in" else (sid(prefix, name), sid(prefix, st.Name))
                    edges.append({"from": a, "to": b, "type": "feeds" if direction == "in" else "produces"})
                    connected += 1
            except Exception as e:
                notes.append(f"{attr}: {e}")
        if notes:
            node["props"]["_notes"] = notes
    # fallback: stream-side connectivity if the operation side gave nothing
    if connected == 0:
        for name, s in mats.items():
            for attr, kind in (("UpstreamOpers", "produces"), ("DownstreamOpers", "feeds")):
                try:
                    for op in seq(call(s, attr)):
                        a, b = (sid(prefix, op.Name), sid(prefix, name)) if kind == "produces" else (sid(prefix, name), sid(prefix, op.Name))
                        edges.append({"from": a, "to": b, "type": kind})
                except Exception:
                    pass


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("out")
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--active", action="store_true")
    g.add_argument("--file")
    ap.add_argument("--source", default="hysys")
    ap.add_argument("--discover", action="store_true")
    a = ap.parse_args()
    import win32com.client
    app = win32com.client.Dispatch("HYSYS.Application")
    case = app.ActiveDocument if a.active else app.SimulationCases.Open(os.path.abspath(a.file))
    nodes, edges, disc = [], [], {}
    walk(case.Flowsheet, "", nodes, edges, a.discover, disc)
    # drop edges that point at nodes we never created (e.g. energy streams)
    ids = {n["id"] for n in nodes}
    dropped = [e for e in edges if e["from"] not in ids or e["to"] not in ids]
    edges = [e for e in edges if e["from"] in ids and e["to"] in ids]
    out = {"source": a.source, "tool": "Aspen HYSYS (COM)", "file": a.file or str(getattr(case, "Name", "active")),
           "nodes": nodes, "edges": edges}
    with open(a.out, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=1)
    print(f"{len(nodes)} nodes, {len(edges)} edges -> {a.out}; dropped {len(dropped)} edges to unknown nodes")
    if a.discover:
        print(json.dumps(disc, indent=1))


if __name__ == "__main__":
    main()
