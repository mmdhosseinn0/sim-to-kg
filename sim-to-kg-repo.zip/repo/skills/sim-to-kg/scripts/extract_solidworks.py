#!/usr/bin/env python
"""SolidWorks assembly -> source JSON via the SolidWorks API (COM). Windows + SolidWorks + pywin32.

usage:
  extract_solidworks.py out.json --active
  extract_solidworks.py out.json --file C:\\cad\\skid.sldasm [--no-mass]

Per component: hierarchy (contains), path, suppressed flag, custom properties, mass; plus mates.
A tag is taken from custom property Tag/TagNumber/Equipment Tag if present, else parsed from the name.
UNTESTED against live SolidWorks in the authoring environment; each read is wrapped and failures are
noted in props._notes. If you have no SolidWorks seat, export STEP and use extract_step.py instead.
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comutil import call

TAG_PROPS = ["Tag", "TagNumber", "Tag Number", "Equipment Tag", "TAG", "Item Number"]
swDocASSEMBLY, swOpenDocOptions_Silent, swOpenDocOptions_ReadOnly = 2, 1, 2


def doc_props(doc):
    out = {}
    try:
        cpm = doc.Extension.CustomPropertyManager("")
        for n in call(cpm, "GetNames") or []:
            try:
                out[n] = cpm.Get(n)
            except Exception:
                pass
    except Exception:
        pass
    return out


def mass_of(doc):
    try:
        return float(doc.Extension.CreateMassProperty().Mass)
    except Exception:
        return None


def open_model(sw, path):
    import pythoncom
    from win32com.client import VARIANT
    err = VARIANT(pythoncom.VT_BYREF | pythoncom.VT_I4, 0)
    warn = VARIANT(pythoncom.VT_BYREF | pythoncom.VT_I4, 0)
    return sw.OpenDoc6(os.path.abspath(path), swDocASSEMBLY, swOpenDocOptions_Silent | swOpenDocOptions_ReadOnly, "", err, warn)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("out")
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--active", action="store_true")
    g.add_argument("--file")
    ap.add_argument("--source", default="solidworks")
    ap.add_argument("--no-mass", action="store_true")
    a = ap.parse_args()
    import win32com.client
    sw = win32com.client.Dispatch("SldWorks.Application")
    model = sw.ActiveDoc if a.active else open_model(sw, a.file)
    if model is None:
        sys.exit("Could not open/find an assembly document.")
    root_name = os.path.splitext(os.path.basename(str(call(model, "GetPathName") or "assembly")))[0]
    nodes = [{"id": root_name, "kind": "assembly", "name": root_name, "props": {"root": True}}]
    edges, known = [], {root_name}
    comps = call(model, "GetComponents", False) or []      # False = all levels
    for c in comps:
        name = str(c.Name2)
        notes = []
        props = {"path": str(call(c, "GetPathName") or "")}
        try:
            props["suppressed"] = bool(call(c, "IsSuppressed"))
        except Exception as e:
            notes.append(f"suppressed: {e}")
        doc = None
        try:
            doc = call(c, "GetModelDoc2")
        except Exception:
            pass
        tag = None
        if doc is not None:
            cp = doc_props(doc)
            props["custom"] = cp
            tag = next((cp[k] for k in TAG_PROPS if cp.get(k)), None)
            if not a.no_mass:
                props["mass_kg"] = mass_of(doc)
        else:
            notes.append("component not loaded (lightweight/suppressed): no custom props or mass")
        try:
            is_asm = int(call(call(c, "GetModelDoc2"), "GetType")) == swDocASSEMBLY if doc is not None else False
        except Exception:
            is_asm = False
        if notes:
            props["_notes"] = notes
        nodes.append({"id": name, "kind": "assembly" if is_asm else "part", "name": name, "tag": tag, "props": props})
        known.add(name)
        parent = call(c, "GetParent")
        pname = str(parent.Name2) if parent is not None else root_name
        edges.append({"from": pname, "to": name, "type": "contains", "props": {"qty": 1}})
    # mates: walk the feature tree for MateGroup
    try:
        feat = call(model, "FirstFeature")
        while feat is not None:
            if str(call(feat, "GetTypeName2")) == "MateGroup":
                sub = call(feat, "GetFirstSubFeature")
                while sub is not None:
                    try:
                        m = call(sub, "GetSpecificFeature2")
                        n = int(call(m, "GetMateEntityCount"))
                        refs = []
                        for i in range(n):
                            ent = m.MateEntity(i)
                            refs.append(str(ent.ReferenceComponent.Name2))
                        for i in range(len(refs)):
                            for j in range(i + 1, len(refs)):
                                if refs[i] in known and refs[j] in known and refs[i] != refs[j]:
                                    edges.append({"from": refs[i], "to": refs[j], "type": "mate",
                                                  "props": {"mate": str(sub.Name)}})
                    except Exception:
                        pass
                    sub = call(sub, "GetNextSubFeature")
            feat = call(feat, "GetNextFeature")
    except Exception as e:
        nodes[0]["props"]["_notes"] = [f"mates not read: {e}"]
    # merge duplicate contains edges into quantities
    merged = {}
    for e in edges:
        if e["type"] == "contains":
            k = (e["from"], e["to"])
            if k in merged:
                merged[k]["props"]["qty"] += 1
                continue
            merged[k] = e
    edges = [e for e in edges if e["type"] != "contains"] + list(merged.values())
    out = {"source": a.source, "tool": "SolidWorks API (COM)", "file": a.file or root_name, "nodes": nodes, "edges": edges}
    with open(a.out, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=1, ensure_ascii=False)
    print(f"{len(nodes)} nodes, {len(edges)} edges -> {a.out}")


if __name__ == "__main__":
    main()
