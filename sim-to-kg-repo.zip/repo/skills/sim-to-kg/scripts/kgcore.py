"""Shared core for sim-to-kg: source-JSON loading, merging, tag reconciliation, outputs.

Source JSON (written by every extractor):
{
  "source": "hysys",            # short unique label for this source
  "tool": "Aspen HYSYS",        # free text
  "file": "plant.hsc",
  "nodes": [{"id": "P-100", "kind": "equipment", "name": "P-100", "tag": null,
             "type": "pump", "props": {...}}],
  "edges": [{"from": "S1", "to": "P-100", "type": "feeds", "props": {}}]
}
kind  : equipment | stream | controller | instrument | part | assembly | other
edge  : feeds (stream->unit) | produces (unit->stream) | flows_to | contains | mate | signal
"""
import csv
import json
import os
import re
from collections import defaultdict

FLOW_EDGES = {"feeds", "produces", "flows_to", "flow"}
TAGGED_KINDS = {"equipment", "part", "assembly", "controller", "instrument"}
TAG_RE = re.compile(r"(?<![A-Za-z0-9])([A-Za-z]{1,4})[-_]?(\d{2,5})([A-Za-z]?)(?![A-Za-z0-9])")


def extract_tag(text):
    """Pull an ISA-style tag (P-101, E100, TK-101A) out of a name. None if absent."""
    if not text:
        return None
    m = TAG_RE.search(str(text))
    if not m:
        return None
    return f"{m.group(1).upper()}-{m.group(2)}{m.group(3).upper()}"


def norm_key(tag):
    """Separator/case-insensitive comparison key: 'p_101' -> 'P101'."""
    return re.sub(r"[^A-Z0-9]", "", str(tag).upper())


def load_aliases(path):
    """CSV with header: source,name,tag  -> {(source, name): tag}. For names like 'Feed Pump'."""
    out = {}
    if path and os.path.exists(path):
        with open(path, newline="", encoding="utf-8-sig") as f:
            for r in csv.DictReader(f):
                out[(r["source"].strip(), r["name"].strip())] = r["tag"].strip()
    return out


def load_source(path):
    with open(path, encoding="utf-8") as f:
        d = json.load(f)
    for k in ("source", "nodes", "edges"):
        if k not in d:
            raise ValueError(f"{path}: missing key '{k}'")
    return d


def merge(sources, aliases=None):
    aliases = aliases or {}
    nodes, edges, warnings = [], [], []
    ids = set()
    for s in sources:
        src = s["source"]
        local = set()
        for n in s["nodes"]:
            gid = f"{src}:{n['id']}"
            if gid in ids:
                warnings.append(f"duplicate node id {gid}")
                continue
            ids.add(gid)
            local.add(n["id"])
            kind = n.get("kind", "other")
            tag = n.get("tag") or aliases.get((src, n.get("name", n["id"])))
            if not tag and kind in TAGGED_KINDS:
                tag = extract_tag(n.get("name", n["id"]))
            nodes.append({"id": gid, "kind": kind, "name": n.get("name", n["id"]),
                          "tag": tag, "source": src, "type": n.get("type"),
                          "props": n.get("props", {})})
        for e in s["edges"]:
            if e["from"] not in local or e["to"] not in local:
                warnings.append(f"{src}: edge {e['from']}->{e['to']} references unknown node")
                continue
            edges.append({"from": f"{src}:{e['from']}", "to": f"{src}:{e['to']}",
                          "type": e["type"], "source": src, "props": e.get("props", {})})
    meta = [{k: s.get(k) for k in ("source", "tool", "file")} for s in sources]
    return {"sources": meta, "nodes": nodes, "edges": edges, "warnings": warnings}


def equipment_flow(g, source):
    """Contract streams/pipes/valves: equipment -> set(next equipment ids), one source."""
    nodes = {n["id"]: n for n in g["nodes"] if n["source"] == source}
    adj = defaultdict(list)
    for e in g["edges"]:
        if e["type"] in FLOW_EDGES and e["from"] in nodes and e["to"] in nodes:
            adj[e["from"]].append(e["to"])
    out = defaultdict(set)
    for nid, n in nodes.items():
        if n["kind"] != "equipment":
            continue
        seen, stack = set(), list(adj[nid])
        while stack:
            x = stack.pop()
            if x in seen:
                continue
            seen.add(x)
            if nodes[x]["kind"] == "equipment":
                out[nid].add(x)
            else:
                stack.extend(adj[x])
    return out


def reconcile(g):
    """Cross-source tag coverage + equipment-level downstream-neighbour comparison."""
    srcs = [s["source"] for s in g["sources"]]
    by_key = defaultdict(lambda: defaultdict(list))
    for n in g["nodes"]:
        if n["tag"]:
            by_key[norm_key(n["tag"])][n["source"]].append(n)
    coverage = []
    for k, per in sorted(by_key.items()):
        tag = next(iter(per.values()))[0]["tag"]
        coverage.append({"key": k, "tag": tag, "sources": sorted(per),
                         "missing_in": [s for s in srcs if s not in per]})
    disp = {c["key"]: c["tag"] for c in coverage}
    flows = {s: equipment_flow(g, s) for s in srcs}
    flow_srcs = [s for s in srcs if any(flows[s].values())]
    id2 = {n["id"]: n for n in g["nodes"]}

    def keys(ids):
        return {norm_key(id2[i]["tag"]) for i in ids if id2[i]["tag"]}

    def downstream(s, key):
        d = set()
        for nid, outs in flows[s].items():
            if id2[nid]["tag"] and norm_key(id2[nid]["tag"]) == key:
                d |= keys(outs)
        return d

    mism = []
    for i, a in enumerate(flow_srcs):
        for b in flow_srcs[i + 1:]:
            ta = {norm_key(n["tag"]) for n in g["nodes"] if n["source"] == a and n["tag"] and n["kind"] == "equipment"}
            tb = {norm_key(n["tag"]) for n in g["nodes"] if n["source"] == b and n["tag"] and n["kind"] == "equipment"}
            common = ta & tb
            for k in sorted(common):
                da, db = downstream(a, k) & common, downstream(b, k) & common
                if da != db:
                    mism.append({"tag": disp[k], "a": a, "b": b,
                                 "downstream_only_in_a": sorted(disp[x] for x in da - db),
                                 "downstream_only_in_b": sorted(disp[x] for x in db - da)})
    return {"coverage": coverage, "flow_sources": flow_srcs, "downstream_mismatches": mism}


def write_outputs(g, rep, outdir):
    os.makedirs(outdir, exist_ok=True)
    with open(os.path.join(outdir, "graph.json"), "w", encoding="utf-8") as f:
        json.dump(g, f, indent=1, ensure_ascii=False)
    id2 = {n["id"]: n for n in g["nodes"]}
    L = ["# Engineering-source knowledge graph", ""]
    L.append("| source | tool | file | nodes | edges |")
    L.append("|---|---|---|---|---|")
    for s in g["sources"]:
        nn = sum(1 for n in g["nodes"] if n["source"] == s["source"])
        ne = sum(1 for e in g["edges"] if e["source"] == s["source"])
        L.append(f"| {s['source']} | {s.get('tool') or ''} | {s.get('file') or ''} | {nn} | {ne} |")
    for s in rep["flow_sources"]:
        L += ["", f"## Equipment-level flow: {s}", ""]
        for nid, outs in sorted(equipment_flow(g, s).items()):
            L.append(f"- {id2[nid]['tag'] or id2[nid]['name']} -> " +
                     ", ".join(sorted(id2[o]["tag"] or id2[o]["name"] for o in outs)))
    asm = [n for n in g["nodes"] if n["kind"] == "assembly"]
    if asm:
        L += ["", "## Assembly structure", ""]
        kids = defaultdict(list)
        for e in g["edges"]:
            if e["type"] == "contains":
                kids[e["from"]].append(e)
        for a in asm:
            ks = ", ".join(id2[e["to"]]["name"] + (f" x{e['props']['qty']}" if e["props"].get("qty", 1) > 1 else "")
                           for e in kids[a["id"]])
            L.append(f"- {a['name']} ({a['source']}): {ks}")
    L += ["", "## Tag coverage across sources", "", "| tag | present in | missing in |", "|---|---|---|"]
    for c in rep["coverage"]:
        L.append(f"| {c['tag']} | {', '.join(c['sources'])} | {', '.join(c['missing_in']) or '-'} |")
    with open(os.path.join(outdir, "summary.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")

    Q = ["# QA report", "", "## Errors / warnings"]
    Q += [f"- {w}" for w in g["warnings"]] or ["- none"]
    Q += ["", "## Tags present in some sources but not others"]
    part = [c for c in rep["coverage"] if c["missing_in"]]
    Q += [f"- {c['tag']}: in {', '.join(c['sources'])}; NOT in {', '.join(c['missing_in'])}" for c in part] or ["- none"]
    Q += ["", "## Downstream-connectivity disagreements (same tag, different next equipment)"]
    Q += [f"- {m['tag']} ({m['a']} vs {m['b']}): only in {m['a']}: {m['downstream_only_in_a'] or '-'}; "
          f"only in {m['b']}: {m['downstream_only_in_b'] or '-'}" for m in rep["downstream_mismatches"]] or ["- none"]
    Q += ["", "## Untagged equipment/parts (cannot be reconciled; add to aliases.csv if they matter)"]
    un = [n for n in g["nodes"] if n["kind"] in ("equipment", "part", "assembly") and not n["tag"]]
    Q += [f"- {n['source']}: {n['name']}" for n in un[:200]] or ["- none"]
    with open(os.path.join(outdir, "qa_report.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(Q) + "\n")

    try:
        import duckdb
    except ImportError:
        return
    p = os.path.join(outdir, "graph.duckdb")
    if os.path.exists(p):
        os.remove(p)
    con = duckdb.connect(p)
    con.execute("create table nodes(id varchar, kind varchar, name varchar, tag varchar, source varchar, type varchar, props varchar)")
    con.execute("create table edges(from_id varchar, to_id varchar, type varchar, source varchar, props varchar)")
    con.executemany("insert into nodes values (?,?,?,?,?,?,?)",
                    [(n["id"], n["kind"], n["name"], n["tag"], n["source"], n["type"], json.dumps(n["props"])) for n in g["nodes"]])
    con.executemany("insert into edges values (?,?,?,?,?)",
                    [(e["from"], e["to"], e["type"], e["source"], json.dumps(e["props"])) for e in g["edges"]])
    con.close()
