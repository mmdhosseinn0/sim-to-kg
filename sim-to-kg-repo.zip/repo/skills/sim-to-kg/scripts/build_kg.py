#!/usr/bin/env python
"""Merge extractor outputs into one graph + summary.md + qa_report.md (+ graph.duckdb if duckdb installed).

usage: build_kg.py OUTDIR source1.json [source2.json ...] [--aliases aliases.csv]
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import kgcore as k


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("outdir")
    ap.add_argument("sources", nargs="+")
    ap.add_argument("--aliases", help="CSV: source,name,tag")
    a = ap.parse_args()
    g = k.merge([k.load_source(p) for p in a.sources], k.load_aliases(a.aliases))
    rep = k.reconcile(g)
    k.write_outputs(g, rep, a.outdir)
    print(f"nodes={len(g['nodes'])} edges={len(g['edges'])} warnings={len(g['warnings'])} "
          f"tag_mismatches={sum(1 for c in rep['coverage'] if c['missing_in'])} "
          f"flow_disagreements={len(rep['downstream_mismatches'])}")
    print(f"wrote {a.outdir}/summary.md, qa_report.md, graph.json")


if __name__ == "__main__":
    main()
