#!/usr/bin/env python
"""Lenient importer: graph.json from the pid-to-kg skill -> sim-to-kg source JSON.

pid-to-kg's schema may differ from the guesses below. Check its references/schema/graph.schema.json and
adjust KIND_MAP / the key names if the printed counts look wrong (0 equipment, 0 edges).

usage: import_pid_kg.py pid_graph.json out.json [--source pid]
"""
import argparse
import json

KIND_MAP = [("equip", "equipment"), ("vessel", "equipment"), ("tank", "equipment"), ("pump", "equipment"),
            ("exchanger", "equipment"), ("column", "equipment"), ("reactor", "equipment"),
            ("compressor", "equipment"), ("instrument", "instrument"), ("controller", "controller"),
            ("loop", "controller")]


def kind_of(n):
    t = str(n.get("type") or n.get("kind") or n.get("label") or "").lower()
    for key, kind in KIND_MAP:
        if key in t:
            return kind
    return "other"


def edge_type(e):
    t = str(e.get("type") or e.get("kind") or e.get("label") or "").lower()
    if any(x in t for x in ("signal", "measure", "control")):
        return "signal"
    if "contain" in t:
        return "contains"
    return "flow"


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("graph")
    ap.add_argument("out")
    ap.add_argument("--source", default="pid")
    a = ap.parse_args()
    d = json.load(open(a.graph, encoding="utf-8"))
    ns = d.get("nodes", [])
    es = d.get("edges", d.get("links", []))
    nodes = [{"id": str(n.get("id")), "kind": kind_of(n), "name": str(n.get("name") or n.get("tag") or n.get("id")),
              "tag": n.get("tag"), "type": n.get("type"), "props": {}} for n in ns]
    edges = [{"from": str(e.get("from", e.get("source"))), "to": str(e.get("to", e.get("target"))),
              "type": edge_type(e)} for e in es]
    json.dump({"source": a.source, "tool": "pid-to-kg", "file": a.graph, "nodes": nodes, "edges": edges},
              open(a.out, "w", encoding="utf-8"), indent=1)
    print(f"{sum(n['kind']=='equipment' for n in nodes)} equipment of {len(nodes)} nodes, {len(edges)} edges -> {a.out}")
