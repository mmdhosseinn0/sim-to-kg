---
name: sim-to-kg
description: Turn Aspen HYSYS / Aspen Plus process simulations and SolidWorks (or any STEP) CAD assemblies into a knowledge graph, and reconcile them against P&ID graphs from the pid-to-kg skill. Use whenever the user mentions HYSYS, Aspen Plus, .hsc/.bkp/.inp simulation files, SolidWorks, .sldasm, STEP assemblies, equipment tag consistency between P&ID / simulation / 3D model, digital-twin data, or wants an LLM-queryable context layer from simulation or CAD files, even if they do not say "knowledge graph".
---

# sim-to-kg

Sibling of `pid-to-kg`. That skill reads drawings with vision; this one reads **structured sources** (simulation and CAD) through APIs/files, writes the same kind of graph, and cross-checks sources against each other by equipment tag.

Pipeline: `extract_*.py` (one per source) -> source JSON -> `build_kg.py` -> `summary.md`, `qa_report.md`, `graph.json`, `graph.duckdb` (if `duckdb` is installed).

## Pick the extractor

| Source | Script | Needs |
|---|---|---|
| HYSYS case (open or .hsc) | `scripts/extract_hysys.py` | Windows, licensed HYSYS, `pywin32` |
| Aspen Plus | export **File > Export > Input File** (.inp), then `scripts/extract_aspen_plus_inp.py` | nothing (pure text) |
| SolidWorks assembly | `scripts/extract_solidworks.py` | Windows, SolidWorks, `pywin32` |
| Any CAD, no license | export STEP AP214, then `scripts/extract_step.py` | nothing |
| P&ID graph from pid-to-kg | `scripts/import_pid_kg.py` | its `graph.json` |

COM extractors only run on the user's Windows machine (Claude Code), not in a sandbox. If you cannot run them, ask the user to run the command and share the JSON.

## Workflow

1. Ask which sources the user has. Work with whatever subset exists; one source alone still yields a graph.
2. Run each extractor to `work/<plant>/sources/<name>.json`. Read the printed counts: 0 nodes or 0 edges means a wrong assumption, not an empty plant.
3. For `import_pid_kg.py`, first read pid-to-kg's `references/schema/graph.schema.json` and adjust `KIND_MAP`/key names if counts look wrong.
4. Run `python scripts/build_kg.py work/<plant>/kg <all source JSONs> [--aliases aliases.csv]`.
5. Open `qa_report.md`. For each item decide: real inconsistency (report it to the user), naming mismatch (add a row to `aliases.csv` with header `source,name,tag`, rebuild), or extractor gap (see below).
6. Answer the user's questions from `summary.md`/`graph.json`/DuckDB. Cite the source label on every claim ("per hysys", "per pid").

## What the QA report means

- **Tag in some sources but not others**: equipment on the P&ID with no simulation block, or a 3D part with no process tag. Often real, sometimes just naming (e.g. HYSYS block called "Feed Pump").
- **Downstream disagreements**: same tag, different next equipment. Compared only over tags both sources know, so missing equipment does not cause false alarms.
- **Untagged equipment**: add aliases if it matters.

## Honesty rules

- The COM extractors were written from the HYSYS and SolidWorks object models without a live licence. Property names can differ by version. Each read is guarded and recorded in `props._notes`. If a note says an attribute failed, run `extract_hysys.py --discover`, find the right name, fix `PROPS`/`CONTROLLER_ATTRS`, rerun. Never fill a missing value from memory.
- Do not invent connections. A missing edge is reported as missing.
- Energy streams, HYSYS spreadsheets/adjusts/recycles logic, SolidWorks Routing pipe runs, and cause-and-effect logic are not extracted yet (see `references/limitations.md`).
- Output is machine-extracted: a qualified engineer must review it before use in design, MOC, HAZOP or LOPA.

## References

- `references/ontology.md`: node/edge kinds and the source JSON schema.
- `references/limitations.md`: what each extractor covers and how to extend it (energy streams, Aspen Plus COM, Routing).
