# Ontology

Source JSON: `{source, tool, file, nodes[], edges[]}`; node `{id, kind, name, tag?, type?, props{}}`; edge `{from, to, type, props{}}`.

| kind | examples |
|---|---|
| equipment | HYSYS/Aspen unit op, P&ID vessel/pump/exchanger |
| stream | material stream (props: T_C, P_kPa, flows, vapour fraction) |
| controller | HYSYS PID/MPC, P&ID loop controller |
| instrument | P&ID transmitter |
| assembly / part | CAD assembly or part (props: path, mass_kg, custom, instances) |

| edge | meaning |
|---|---|
| feeds | stream -> unit op |
| produces | unit op -> stream |
| flows_to | equipment/segment -> next (P&ID style) |
| contains | assembly -> child (props.qty) |
| mate | CAD mate between two components |
| signal | controller PV/OP link |

Global ids are `<source>:<id>`. Tags are normalised (case, `-`/`_` removed) only for comparison; display form is kept. Equipment-level flow collapses streams/pipes/valves between equipment (kgcore.equipment_flow).
