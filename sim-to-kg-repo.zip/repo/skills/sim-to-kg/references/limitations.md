# Limitations and extension points

- HYSYS: energy streams are not nodes yet (op.AttachedFeeds covers material only). Spreadsheets, Adjust, Set, Recycle logic not extracted. Controller PV/OP attribute names are guessed (`CONTROLLER_ATTRS`); use `--discover`.
- Aspen Plus: .inp parsing reads FLOWSHEET connectivity, block type, PARAM and STREAM key=values. Heat/work streams appear mixed with material streams in IN/OUT. Hierarchies and Design-Spec/Calculator blocks are not interpreted. A COM route (`Apwn.Document`, tree path `\Data\Streams`, `\Data\Blocks`) is a possible extension for results.
- SolidWorks: assembly tree, custom properties, mass, mates. Not covered: Routing pipe runs/connection points, configurations other than active, lightweight components (reported in `_notes`). Open assemblies in Resolved mode for best results.
- STEP: structure only, no geometry, no custom properties (SolidWorks property tags are usually lost).
- Tag matching is regex-based (1-4 letters + 2-5 digits + optional letter). Use `aliases.csv` for descriptive names.
